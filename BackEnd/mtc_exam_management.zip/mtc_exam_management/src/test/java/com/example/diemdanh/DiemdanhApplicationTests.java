package com.example.diemdanh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiemdanhApplicationTests {

	@Test
	void contextLoads() {
	}

}
