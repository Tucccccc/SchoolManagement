package com.example.diemdanh.dto.dtoenum;

public enum ClassStatus {
    ACTIVE,
    INACTIVE,
    FULL,
    CANCELLED
}
