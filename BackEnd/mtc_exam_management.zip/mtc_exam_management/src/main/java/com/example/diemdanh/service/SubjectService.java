package com.example.diemdanh.service;

import com.example.diemdanh.dto.SubjectDTO;

public interface SubjectService {
	// * Add Subject
	// Input: SubjectDTO subjectRequest
	// Output: SubjectDTO subjectDTO
	// Giang Ngo Truong 09/04/2025
	SubjectDTO addSubject(SubjectDTO subjectRequest);
}
