package com.example.diemdanh.service;

import java.util.List;

import com.example.diemdanh.dto.ClassDTO;
import com.example.diemdanh.dto.ResponseData;
import com.example.diemdanh.dto.request.ClassRequest;
import com.example.diemdanh.dto.response.ClassResponse;

public interface ClassService {
	// * Add Class
	// Input: ClassDTO addClass
	// Output: ClassDTO ClassDTO
	// Giang Ngo Truong 17/03/2025
	ResponseData<ClassResponse> addClass(ClassRequest classRequest);
	
	// * Get all Class
	// Input:
	// Output: ClassDTO ClassDTO
	// Giang Ngo Truong 17/03/2025
	ResponseData<List<ClassResponse>> getAllClass();
	
	// * Get Class by ID
	// Input: Long Id
	// Output: ClassDTO ClassDTO
	// Giang Ngo Truong 17/03/2025
	ClassDTO getClassById(Long Id);
	
	// * assignStudentToClass
	// Input: List<Long> Id
	// Output: Boolean isSuccess
	// Giang Ngo Truong 17/03/2025
	void assignStudentToClass(List<Long> lstIdStudent, Long classId);
}