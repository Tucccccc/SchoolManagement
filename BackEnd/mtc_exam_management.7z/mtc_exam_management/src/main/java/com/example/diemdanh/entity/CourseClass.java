package com.example.diemdanh.entity;

public class CourseClass {

}
